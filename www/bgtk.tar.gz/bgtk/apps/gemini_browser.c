#include <bgce.h>
#include <bgtk.h>
#include <ctype.h>
#include <errno.h>
#include <linux/input.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tls.h>
#include <unistd.h>

static struct BGTK_Context *ctx = NULL;
static struct BGTK_Widget *content_scroll = NULL;
static struct BGTK_Widget *addr_input = NULL;

static char current_url[512] = "gemini://geminiprotocol.net/";

static struct BGTK_Widget *link_target_widgets[128];
static char link_targets[128][512];
static int num_page_links = 0;

static void load_url(const char *url);

/* --- URL resolution (relative links, ../ etc) --- */
static void resolve_url(const char *base, const char *rel, char *out, size_t outlen)
{
	if (!rel || !*rel) {
		strncpy(out, base, outlen - 1);
		out[outlen - 1] = 0;
		return;
	}
	if (strstr(rel, "://") || !strncmp(rel, "gemini:", 7)) {
		strncpy(out, rel, outlen - 1);
		out[outlen - 1] = 0;
		return;
	}

	char bhost[256] = {0};
	char bpath[512] = {0};
	int bport = 1965;

	const char *p = base;
	if (!strncmp(p, "gemini://", 9))
		p += 9;
	const char *he = strchr(p, '/');
	const char *pe = strchr(p, ':');
	if (pe && (!he || pe < he)) {
		int hl = (int)(pe - p);
		if (hl > 255)
			hl = 255;
		memcpy(bhost, p, hl);
		bhost[hl] = 0;
		bport = atoi(pe + 1);
		if (he)
			strncpy(bpath, he, sizeof(bpath) - 1);
		else
			strcpy(bpath, "/");
	} else if (he) {
		int hl = (int)(he - p);
		memcpy(bhost, p, hl);
		bhost[hl] = 0;
		strncpy(bpath, he, sizeof(bpath) - 1);
	} else {
		strncpy(bhost, p, sizeof(bhost) - 1);
		strcpy(bpath, "/");
	}
	if (!bpath[0])
		strcpy(bpath, "/");

	char portpart[32] = "";
	if (bport != 1965)
		snprintf(portpart, sizeof(portpart), ":%d", bport);

	if (rel[0] == '/') {
		snprintf(out, outlen, "gemini://%s%s%s", bhost, portpart, rel);
		return;
	}

	/* relative: dirname(base) + rel, with ../ handling */
	char dir[512];
	strncpy(dir, bpath, sizeof(dir) - 1);
	char *ls = strrchr(dir, '/');
	if (ls)
		*(ls + 1) = 0;
	else
		strcpy(dir, "/");

	char full[1024];
	snprintf(full, sizeof(full), "%s%s", dir, rel);

	/* normalize segments */
	char *segs[64];
	int nseg = 0;
	char *tmp = strdup(full);
	char *save = NULL;
	char *seg = strtok_r(tmp, "/", &save);
	while (seg) {
		if (!strcmp(seg, ".") || !*seg) {
			/* skip */
		} else if (!strcmp(seg, "..")) {
			if (nseg > 0)
				nseg--;
		} else {
			segs[nseg++] = seg;
		}
		seg = strtok_r(NULL, "/", &save);
	}

	char norm[1024] = "/";
	for (int i = 0; i < nseg; i++) {
		strcat(norm, segs[i]);
		if (i + 1 < nseg)
			strcat(norm, "/");
	}
	free(tmp);

	snprintf(out, outlen, "gemini://%s%s%s", bhost, portpart, norm);
}

/* --- Gemini fetch over TLS --- */
static int fetch_gemini(const char *req_url, int *out_status, char **out_meta, char **out_body)
{
	*out_status = 0;
	*out_meta = NULL;
	*out_body = NULL;

	char host[256] = {0};
	char path[768] = "/";
	int port = 1965;

	const char *p = req_url;
	if (!strncmp(p, "gemini://", 9))
		p += 9;
	const char *he = strchr(p, '/');
	const char *pe = strchr(p, ':');
	if (pe && (!he || pe < he)) {
		int hl = (int)(pe - p);
		if (hl > 255)
			hl = 255;
		memcpy(host, p, hl);
		host[hl] = 0;
		port = atoi(pe + 1);
		if (he)
			strncpy(path, he, sizeof(path) - 1);
	} else if (he) {
		int hl = (int)(he - p);
		memcpy(host, p, hl);
		host[hl] = 0;
		strncpy(path, he, sizeof(path) - 1);
	} else {
		strncpy(host, p, sizeof(host) - 1);
	}
	if (!host[0])
		return -1;
	if (port < 1)
		port = 1965;
	if (!path[0])
		strcpy(path, "/");

	/* full selector is the original req_url (spec) */
	char selector[1024];
	strncpy(selector, req_url, sizeof(selector) - 1);
	selector[sizeof(selector) - 1] = '\0';

	/* Gemini commonly uses TOFU; match prior OpenSSL VERIFY_NONE behaviour. */
	if (tls_init() == -1)
		return -2;

	struct tls_config *cfg = tls_config_new();
	if (!cfg)
		return -2;
	tls_config_insecure_noverifycert(cfg);
	tls_config_insecure_noverifyname(cfg);

	struct tls *ctx_tls = tls_client();
	if (!ctx_tls) {
		tls_config_free(cfg);
		return -2;
	}
	if (tls_configure(ctx_tls, cfg) == -1) {
		bgtk_log("tls_configure: %s", tls_error(ctx_tls));
		tls_free(ctx_tls);
		tls_config_free(cfg);
		return -2;
	}

	char portstr[16];
	snprintf(portstr, sizeof(portstr), "%d", port);
	if (tls_connect(ctx_tls, host, portstr) == -1) {
		bgtk_log("tls_connect %s:%s: %s", host, portstr, tls_error(ctx_tls));
		tls_free(ctx_tls);
		tls_config_free(cfg);
		return -6;
	}

	char req[1200];
	int rlen = snprintf(req, sizeof(req), "%s\r\n", selector);
	if (tls_write(ctx_tls, req, (size_t)rlen) < 0) {
		bgtk_log("tls_write: %s", tls_error(ctx_tls));
		tls_close(ctx_tls);
		tls_free(ctx_tls);
		tls_config_free(cfg);
		return -7;
	}

	/* read header up to first \r\n */
	char hbuf[1024] = {0};
	int hlen = 0;
	while (hlen < (int)sizeof(hbuf) - 1) {
		ssize_t n = tls_read(ctx_tls, hbuf + hlen, 1);
		if (n <= 0)
			break;
		hlen += (int)n;
		if (hlen >= 2 && hbuf[hlen - 2] == '\r' && hbuf[hlen - 1] == '\n')
			break;
	}
	hbuf[hlen] = 0;

	int status = 0;
	char meta[512] = {0};
	if (sscanf(hbuf, "%d %511[^\r\n]", &status, meta) < 1)
		status = 59;
	*out_status = status;
	if (out_meta)
		*out_meta = strdup(meta);

	/* read body */
	size_t cap = 8192;
	size_t blen = 0;
	char *body = malloc(cap);
	if (!body) {
		tls_close(ctx_tls);
		tls_free(ctx_tls);
		tls_config_free(cfg);
		return -8;
	}
	for (;;) {
		char rbuf[1024];
		ssize_t n = tls_read(ctx_tls, rbuf, sizeof(rbuf));
		if (n <= 0)
			break;
		if (blen + (size_t)n + 1 > cap) {
			cap = cap * 2 + (size_t)n;
			char *nb = realloc(body, cap);
			if (!nb) {
				free(body);
				tls_close(ctx_tls);
				tls_free(ctx_tls);
				tls_config_free(cfg);
				return -8;
			}
			body = nb;
		}
		memcpy(body + blen, rbuf, (size_t)n);
		blen += (size_t)n;
	}
	body[blen] = 0;
	*out_body = body;

	tls_close(ctx_tls);
	tls_free(ctx_tls);
	tls_config_free(cfg);
	return 0;
}

/* click handler for link text widgets */
static int gemini_link_handler(struct BGTK_Widget *w, struct InputEvent ev)
{
	if (ev.code == BTN_LEFT && ev.value == 1) {
		for (int i = 0; i < num_page_links; i++) {
			if (link_target_widgets[i] == w) {
				load_url(link_targets[i]);
				return 1;
			}
		}
	}
	return 0;
}

/* Simple word-wrap for long paragraphs and link labels. Returns malloc'ed array of lines (caller frees). */
static char **wrap_text(FT_Face face, const char *text, int max_width, int *nlines)
{
	*nlines = 0;
	if (!face || !text || !*text || max_width < 20) return NULL;
	char **lines = NULL;
	int n = 0, cap = 0;
	int len = strlen(text);
	int i = 0;
	while (i < len) {
		int j = i;
		int last_space = -1;
		int w = 0;
		for (; j < len; j++) {
			unsigned char ch = (unsigned char)text[j];
			if (FT_Load_Char(face, ch, FT_LOAD_DEFAULT) == 0)
				w += face->glyph->advance.x >> 6;
			if (w > max_width && j > i) break;
			if (isspace(ch)) last_space = j;
		}
		int end = (j >= len) ? len : (last_space > i ? last_space : j);
		int lnlen = end - i;
		char *ln = malloc(lnlen + 1);
		memcpy(ln, text + i, lnlen);
		ln[lnlen] = 0;
		while (lnlen > 0 && isspace((unsigned char)ln[lnlen-1])) ln[--lnlen] = 0;
		if (n >= cap) {
			cap = cap ? cap * 2 : 8;
			lines = realloc(lines, cap * sizeof(char *));
		}
		lines[n++] = ln;
		i = end;
		while (i < len && isspace((unsigned char)text[i])) i++;
	}
	*nlines = n;
	return lines;
}

/* replace page content from gemtext body */
static void rebuild_content_from_gemtext(const char *body)
{
	/* free old line widgets (all plain text) */
	if (content_scroll->data.scrollable.items) {
		for (int i = 0; i < content_scroll->data.scrollable.widget_count; i++) {
			struct BGTK_Widget *tw = content_scroll->data.scrollable.items[i];
			if (tw) {
				free(tw->data.text.text);
				free(tw);
			}
		}
		free(content_scroll->data.scrollable.items);
		content_scroll->data.scrollable.items = NULL;
		content_scroll->data.scrollable.widget_count = 0;
	}
	num_page_links = 0;

	if (!body)
		return;

	int max_text_w = 480;
	if (content_scroll && content_scroll->w > 100)
		max_text_w = content_scroll->w - 8;

	/* copy for strtok */
	char *work = strdup(body);
	if (!work)
		return;

	/* collect new widgets */
	struct BGTK_Widget **new_items = NULL;
	int cap = 0;
	int cnt = 0;

	char *save = NULL;
	char *line = strtok_r(work, "\n", &save);
	int in_pre = 0;
	while (line) {
		/* strip \r */
		char *cr = strchr(line, '\r');
		if (cr)
			*cr = 0;

		if (!strncmp(line, "```", 3)) {
			in_pre = !in_pre;
			line = strtok_r(NULL, "\n", &save);
			continue;
		}

		char vis[768];
		int is_link = 0;
		char link_to[512] = {0};
		int header_level = 0;
		int item_color = 0;

		if (in_pre) {
			snprintf(vis, sizeof(vis), "  %s", line);
		} else if (!strncmp(line, "=>", 2)) {
			/* link */
			char tgt[512] = {0};
			char disp[512] = {0};
			const char *rest = line + 2;
			while (*rest == ' ' || *rest == '\t')
				rest++;
			const char *sp = rest;
			while (*sp && *sp != ' ' && *sp != '\t')
				sp++;
			int tl = (int)(sp - rest);
			if (tl > 0 && tl < (int)sizeof(tgt))
				memcpy(tgt, rest, tl);
			tgt[tl] = 0;
			while (*sp == ' ' || *sp == '\t')
				sp++;
			if (*sp)
				strncpy(disp, sp, sizeof(disp) - 1);
			else
				strncpy(disp, tgt, sizeof(disp) - 1);

			snprintf(vis, sizeof(vis), "=> %s", disp);
			strncpy(link_to, tgt, sizeof(link_to) - 1);
			is_link = 1;
			item_color = 10;
		} else if (!strncmp(line, "# ", 2)) {
			snprintf(vis, sizeof(vis), "%s", line + 2);
			header_level = 1;
		} else if (!strncmp(line, "## ", 3)) {
			snprintf(vis, sizeof(vis), "%s", line + 3);
			header_level = 2;
		} else if (!strncmp(line, "### ", 4)) {
			snprintf(vis, sizeof(vis), "%s", line + 4);
			header_level = 3;
		} else if (!strncmp(line, "> ", 2)) {
			snprintf(vis, sizeof(vis), "%s", line);
		} else if (!strncmp(line, "* ", 2)) {
			snprintf(vis, sizeof(vis), "\xe2\x80\xa2 %s", line + 2);
			item_color = 10;
		} else {
			snprintf(vis, sizeof(vis), "%s", line);
		}

		char resolved[512] = {0};
		if (is_link)
			resolve_url(current_url, link_to, resolved, sizeof(resolved));

		if (header_level > 0 && cnt > 0) {
			new_items[cnt-1]->h += 5;  /* increase the top spacing a little before headings */
		}

		if (header_level > 0) {
			FT_Set_Pixel_Sizes(ctx->ft_face, 0, ctx->font_size + 4 - header_level);
		}
		if (!in_pre) {
			int nsubs = 0;
			char **subs = wrap_text(ctx->ft_face, vis, max_text_w, &nsubs);
			for (int s = 0; s < nsubs; s++) {
				struct BGTK_Widget *tw = bgtk_text(ctx, subs[s], (BGTK_Options){.padding = 1, .margin = 1});
				if (!tw) continue;
				if (header_level > 0) {
					tw->data.text.header_level = header_level;
				}
				if (item_color) {
					tw->data.text.header_level = item_color;
				}
				if (is_link && num_page_links < 128) {
					link_target_widgets[num_page_links] = tw;
					strncpy(link_targets[num_page_links], resolved, sizeof(link_targets[0]) - 1);
					num_page_links++;
					tw->handle_event = gemini_link_handler;
				}
				if (s < nsubs - 1) {
					tw->h -= 3;  /* decrease a little for lines in the same paragraph (tighter leading between wraps) */
				}
				if (s == nsubs - 1) {
					tw->h += 5;  /* extra vertical space after this logical block */
				}
				if (cnt >= cap) {
					cap = cap ? cap * 2 : 32;
					struct BGTK_Widget **ni = realloc(new_items, (size_t)cap * sizeof(*ni));
					if (!ni) {
						free(tw->data.text.text);
						free(tw);
						break;
					}
					new_items = ni;
				}
				new_items[cnt++] = tw;
			}
			for (int s = 0; s < nsubs; s++) free(subs[s]);
			free(subs);
		} else {
			struct BGTK_Widget *tw = bgtk_text(ctx, vis, (BGTK_Options){.padding = 1, .margin = 1});
			if (tw) {
				tw->h += 4;  /* space after pre block */
				if (cnt >= cap) {
					cap = cap ? cap * 2 : 32;
					struct BGTK_Widget **ni = realloc(new_items, (size_t)cap * sizeof(*ni));
					if (!ni) {
						free(tw->data.text.text);
						free(tw);
					} else {
						new_items = ni;
						new_items[cnt++] = tw;
					}
				} else {
					new_items[cnt++] = tw;
				}
			}
		}
		if (header_level > 0) {
			FT_Set_Pixel_Sizes(ctx->ft_face, 0, ctx->font_size);
		}

		line = strtok_r(NULL, "\n", &save);
	}
	free(work);

	content_scroll->data.scrollable.items = new_items;
	content_scroll->data.scrollable.widget_count = cnt;
	content_scroll->data.scrollable.scroll_y = 0;
}

/* main navigation entry */
static void load_url(const char *url)
{
	if (!url || !*url)
		return;

	strncpy(current_url, url, sizeof(current_url) - 1);
	current_url[sizeof(current_url) - 1] = 0;

	/* follow redirects a few times */
	char tourl[512];
	strncpy(tourl, url, sizeof(tourl) - 1);
	int redirects = 0;
	int status = 0;
	char *meta = NULL;
	char *body = NULL;
	int feres = -1;

	for (;;) {
		if (meta) {
			free(meta);
			meta = NULL;
		}
		if (body) {
			free(body);
			body = NULL;
		}
		feres = fetch_gemini(tourl, &status, &meta, &body);
		if (feres == 0 && (status == 30 || status == 31) && meta && *meta && redirects < 5) {
			char next[512];
			resolve_url(tourl, meta, next, sizeof(next));
			strncpy(tourl, next, sizeof(tourl) - 1);
			redirects++;
			continue;
		}
		break;
	}

	/* update current to final */
	strncpy(current_url, tourl, sizeof(current_url) - 1);

	/* build UI lines */
	if (feres != 0 || status / 10 != 2) {
		char errline[256];
		snprintf(errline, sizeof(errline), "Error %d %s", status, meta ? meta : "");
		struct BGTK_Widget *et = bgtk_text(ctx, errline, (BGTK_Options){.padding = 2, .margin = 1});
		struct BGTK_Widget **errs = calloc(1, sizeof(*errs));
		if (errs)
			errs[0] = et;
		/* free previous via rebuild but force single */
		if (content_scroll->data.scrollable.items) {
			for (int i = 0; i < content_scroll->data.scrollable.widget_count; i++) {
				struct BGTK_Widget *tw = content_scroll->data.scrollable.items[i];
				free(tw->data.text.text);
				free(tw);
			}
			free(content_scroll->data.scrollable.items);
		}
		content_scroll->data.scrollable.items = errs;
		content_scroll->data.scrollable.widget_count = errs ? 1 : 0;
		content_scroll->data.scrollable.scroll_y = 0;
		num_page_links = 0;
	} else {
		rebuild_content_from_gemtext(body);
	}

	/* sync address bar (it serves as the URL display) */
	free(addr_input->data.text_input.text);
	addr_input->data.text_input.text = strdup(current_url);
	addr_input->data.text_input.cursor_pos = (uint32_t)strlen(current_url);
	addr_input->data.text_input.scroll_x = 0;

	if (meta)
		free(meta);
	if (body)
		free(body);

	bgtk_draw_widgets(ctx);
}

static void go_button_cb(void *userdata)
{
	(void)userdata;
	if (addr_input)
		load_url(addr_input->data.text_input.text);
}

static void addr_on_enter(void)
{
	if (addr_input)
		load_url(addr_input->data.text_input.text);
}

int main(void)
{
	bgtk_log_open("gemini_browser");
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	if (tls_init() == -1) {
		bgtk_log("tls_init failed");
		return 1;
	}

	int conn_fd = bgce_connect();
	if (conn_fd < 0) {
		bgtk_log_errno("bgce_connect");
		return -1;
	}

	int width = 640;
	int height = 480;
	struct BufferRequest req = {.width = width, .height = height};
	void *buffer = bgce_get_buffer(conn_fd, req);
	if (!buffer) {
		bgtk_log("bgce_get_buffer %dx%d failed", width, height);
		bgce_disconnect(conn_fd);
		return -3;
	}

	ctx = bgtk_init(conn_fd, buffer, width, height);
	if (!ctx) {
		bgtk_log("bgtk_init failed");
		return 1;
	}

	int usable_w = width - 20;

	/* create button first to know its size, then size the input to make the row (address bar + button) full width */
	struct BGTK_Widget *go_label = bgtk_text(ctx, "Go", (BGTK_Options){.padding = 2, .margin = 0});
	struct BGTK_Widget *go_btn = bgtk_button(ctx, go_label, go_button_cb, NULL,
						 (BGTK_Options){.padding = 4, .margin = 2});
	int input_w = usable_w - go_btn->w - 16;  /* leave room for row padding/margins */
	addr_input = bgtk_text_input(ctx, "gemini://geminiprotocol.net/", input_w > 100 ? input_w : 400, 0,
				     (BGTK_Options){.padding = 4, .margin = 2});
	addr_input->data.text_input.on_enter = addr_on_enter;

	struct BGTK_Widget *addr_items[2] = {addr_input, go_btn};
	struct BGTK_Widget *addr_row = bgtk_list(ctx, addr_items, 2,
						 (BGTK_Options){.orientation = BGTK_LIST_HORIZONTAL, .padding = 2, .margin = 1});

	/* content: scrollable holding the list of text items (gemtext lines) */
	content_scroll = bgtk_scrollable(ctx, NULL, 0, (BGTK_Options){.padding = 2, .margin = 3});

	/* leave room inside the frame for addr_row + list spacing */
	int v_margins = 16;
	int reserved = (addr_row ? addr_row->h : 24) + v_margins;
	int scroll_h = height - reserved - 24;
	if (scroll_h < 100)
		scroll_h = 180;
	content_scroll->w = usable_w;
	content_scroll->h = scroll_h;

	/* vertical list inside the frame: [content scroll of texts, address bar at bottom] */
	struct BGTK_Widget *main_items[2] = {content_scroll, addr_row};
	struct BGTK_Widget *main_list = bgtk_list(ctx, main_items, 2,
						  (BGTK_Options){.orientation = BGTK_LIST_VERTICAL, .padding = 2, .margin = 2});

	/* single frame around everything (content + address bar at bottom) */
	struct BGTK_Widget *frame = bgtk_frame(ctx, main_list, width, height,
					       (BGTK_Options){.padding = 4, .margin = 0});

	ctx->root_widget = frame;
	bgtk_set_focus(ctx, addr_input);

	/* initial page */
	load_url(current_url);

	printf("gemini_browser starting (%dx%d) on %s\n", width, height, current_url);

	struct BGCEMessage msg;
	ssize_t bytes;
	while (1) {
		bytes = bgce_recv_msg(ctx->conn_fd, &msg);
		if (bytes <= 0) {
			if (bytes == 0)
				bgtk_log("server closed connection");
			else if (errno != EINTR)
				bgtk_log_errno("bgce_recv_msg");
			break;
		}

		int res = 0;
		switch (msg.type) {
		case MSG_INPUT_EVENT:
			if (msg.data.input_event.type == EV_REL ||
			    msg.data.input_event.type == EV_ABS)
				break;
			bgtk_update_modifiers(ctx, msg.data.input_event);
			if (bgtk_is_app_quit_event(ctx, msg.data.input_event))
				goto done;
			res = bgtk_handle_input_event(ctx, msg.data.input_event);
			break;
		case MSG_FOCUS_CHANGE:
			bgtk_set_window_focus(ctx, msg.data.focus_event.state);
			break;
		case MSG_BUFFER_CHANGE:
			if (bgtk_handle_buffer_change(ctx, &msg.data.buffer_reply) == 0) {
				if (ctx->root_widget) {
					ctx->root_widget->w = ctx->width;
					ctx->root_widget->h = ctx->height;
				}
				bgtk_draw_widgets(ctx);
			}
			break;
		default:
			break;
		}
		if (res)
			bgtk_draw_widgets(ctx);
	}
done:
	bgtk_destroy(ctx);
	return 0;
}
